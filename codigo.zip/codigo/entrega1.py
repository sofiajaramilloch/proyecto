import pandas as pd
data = pd.read_csv('calles_de_medellin_con_acoso.csv', sep=";").values
print(data)